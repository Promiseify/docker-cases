#!/bin/bash

# keepalived1对应mysql1，只检查本地MySQL实例
MYSQL_HOST="172.16.0.21"  # mysql1的地址
MYSQL_PORT="3306"
MYSQL_USER="root"
MYSQL_PASS="root123"

# 简单的ping检查
mysqladmin ping -h ${MYSQL_HOST} -P ${MYSQL_PORT} -u${MYSQL_USER} -p${MYSQL_PASS} &>/dev/null

# 获取退出状态
EXIT_CODE=$?

if [ ${EXIT_CODE} -eq 0 ]; then
    # MySQL正常运行
    exit 0
else
    # MySQL不可访问
    exit 1
fi